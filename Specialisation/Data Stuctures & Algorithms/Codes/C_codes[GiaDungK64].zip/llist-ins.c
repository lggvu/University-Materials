#include <stdio.h>
#include <stdlib.h>
typedef struct
{ int data;
  struct Node *next;
}Node;
//Insert a new node at the beginning of a singly link list
int main() {
        Node* head;
	Node* second = NULL;
	Node* third = NULL;
	
	head = (Node*)malloc(sizeof(Node));
	second = (Node*)malloc(sizeof(Node));
	third = (Node*)malloc(sizeof(Node));

	printf("Addresses of initial nodes: head %u second %u third %u \n",head,second,third);

	printf("\n");
	
	head->data = 1;
	head->next = second;
	second->data= 2;
	second->next = third;
	third->data = 3;
	third->next = NULL;
	
	Node* current;
	for (current = head; current != NULL; current = current->next)
	  printf("Data %d next pointer %u \n",current->data,current->next);

	printf("\n");
	Node* newnode;
	newnode = (Node*)malloc(sizeof(Node));
	newnode->next = head;
	head = newnode;
	newnode->data = 0;
	printf("Adress of new head %8u \n",head);

	printf("\n");
	for (current = head; current != NULL; current = current->next)
	  printf("Data %d next pointer %u \n",current->data,current->next);
	return 0;
}
