#include <stdio.h>
#include <stdlib.h>
//Show how to use and declare arrays with malloc	
int main()
{
  int array1[12] = {1,2,3,4,5,6,7,8,9,10,11,12};

  int *array2;
  array2 = (int *)malloc(12*sizeof(int));
  for (int i = 0; i < 12;i++)
    array2[i] = i+1;

  printf("Address    Contents %8u \n",array2);
  for (int i=0; i < 12; i++)
    printf("%8u  %d \n",&array2[i], array2[i]);

  //-------------------------------------------------------------
  //int  a[3][4] = {1,2,3,4,5,6,7,8,9,10,11,12};
   int rows=3, cols =4;  
   int *a;
   a = (int *)malloc(rows*cols*sizeof(int));
   
   for (int i=0; i < rows; i++)
     for (int j=0; j < cols; j++)
       a[i*cols+j] = i*cols+j+1;
       
   printf("Address    Contents %8u \n",a);
   for (int i=0; i < rows; i++)
     for (int j=0; j < cols; j++)
       printf("%8u  %d \n",a +((i*cols)+j),a[i*cols+j]);
  
}
