#include <stdio.h>
#include <stdlib.h>

#define maxSize 5

int front = maxSize - 1;
int rear = maxSize-1;

//Implement queues using a circular array

int sizeQ(Q) //returns the number of elements currently in the queue Q
{
      int size = (maxSize - front + rear) % maxSize;
      return size;   
}
isEmpty(Q) // returns true if queue Q is empty 
{
  if (rear == front) return (rear == front);
    else return 0;
}
isFull(Q) /*returns "true if Q is full, indicates that we already use  the maximum memory for queue; otherwise returns �false� */
{    
    if ((rear + 1) % maxSize == front) return 1;
    else return 0; 
}
int frontQ(int *Q)  //returns the item that is in front (head) of queue Q or returns error if queue Q is empty. 
{
  if (isEmpty(Q) == 1) return -1;
    //printf("Front %d \n",(front+1)%maxSize);
  else return Q[(front+1)%maxSize];
}
int enqueue(int *Q,int x) 
{ 
   if (isFull(Q)) printf("Queue is FULL\n");
   else
   {   rear = (rear + 1) % maxSize;
     Q[rear] = x;       
   }
}
int dequeue(int *Q)
{  if (isEmpty(Q)) printf("Queue is EMPTY\n");
   else
   {   front = (front + 1) % maxSize;
       return Q[front];       
   }
}
int main() {
   int ch,n,i;   int m;
  
   int Q[maxSize];
   while(1)
   {  printf("\n\n======================\n");
      printf(" STACK TEST PROGRAM \n");
      printf("======================\n");
      printf(" 1.Enqueue\n 2.Dequeue\n 3.Display front queue \n 4.Size of the queue \n 5.Exit\n");
      printf("----------------------\n");
      printf("Input number to select the appropriate operation: ");
      scanf("%d",&ch); printf("\n\n");
switch(ch) {
     case 1:    printf("Input integer number to insert into queue: ");
                scanf("%d",&m);
                enqueue(Q, m); break; 
     case 2:    m=dequeue(Q);
	        printf("\n Data Value of the popped node: %d\n",m); 
                break;
     case 3:    m = frontQ(Q);
                if (m==-1) printf("Queue is empty\n");
                else printf("Front value is %d \n",m);
                break;
     case 4:    printf("The # of items in the queue is %d\n",sizeQ(Q)); break;
     case 5:    printf("\n  Bye! Bye! \n\n"); 
                exit(0);    break;
     default:   printf("Wrong choice"); 
   } //switch
  } // end while
} //end main

