#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

//different operations on a doubly link list
typedef struct dllist{
 int number;
 struct dllist *next;
 struct dllist *prev;
} dllist;
dllist *head, *tail;

/* Insert a new node p at the end of the list */
void append_node(dllist *p);
/* Insert a new node p after a node pointed by the pointer after */
void insert_node(dllist *p, dllist *after);
/* Delete a node pointed by the pointer p */
void delete_node(dllist *p);
/* Insert a new node p at the end of the list */
void append_node(dllist *p) {
   if(head == NULL) 
   {
      head = p;
      p->prev = NULL; 
   }
   else {
     tail->next = p;
     p->prev = tail;
   }
   tail = p;
   p->next = NULL;
}
/* Insert a new node p after a node pointed by the pointer after */
void insert_node(dllist *p, dllist *after) {
 p->next = after->next;
 p->prev = after;
 if(after->next != NULL)
   {
     struct dllist * temp=after->next;
     temp->prev = p;
   }
 else
     tail = p;
 after->next = p;
 }
/* Delete a node pointed by the pointer p */
void delete_node(dllist *p) {
 if(p->prev == NULL)
     head = p->next;
 else  p->prev->next = p->next;
 if(p->next == NULL)
     tail = p->prev;
 else  p->next->prev = p->prev;
}
int main( ) {
  dllist *tempnode; int i;
  printf("Creating a doubly link list\n");
 /* add some numbers to the double linked list */
 for(i = 1; i <= 5; i++) {
    tempnode = (dllist *)malloc(sizeof(dllist));
    tempnode->number = i * i;
    printf("node # %d node address %8u \n",i,tempnode);
    append_node(tempnode);
 }
/* print the dll list forward */
  printf(" Traverse the dll list forward \n");
  for(tempnode = head; tempnode != NULL; tempnode = tempnode->next) 
    printf("%d  %8u \n", tempnode->number,tempnode); 

 /* print the dll list backward */
 printf(" Traverse the dll list backward \n");
 for(tempnode = tail; tempnode != NULL; tempnode = tempnode->prev) 
   printf("%d  %8u \n", tempnode->number,tempnode); 
/* destroy the dll list */
 while(head != NULL) delete_node(head);
 return 0;
}
