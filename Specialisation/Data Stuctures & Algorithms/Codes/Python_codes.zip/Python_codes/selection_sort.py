import random
import time


def selection_sort(arr):
    n = len(arr)
    for i in range(n):
        min_index = i
        min = arr[i]
        for j in range(i + 1, n):
            if arr[j] < min:
                min_index = j
                min = arr[j]
        arr[min_index] = arr[i]
        arr[i] = min
    return arr


if __name__ == '__main__':
    # n = int(input('Length of the array: '))
    # # arr = [random.randint(1, n) for _ in range(n)]
    # start = time.time()
    # selection_sort(arr)
    # end = time.time()
    # print(f'Execution time: {end-start}s')
    # print(arr)
    # print(selection_sort(arr))

    arr = [1, 9, 4, 5, 0, 8, 6, 13, 21, 15, 7]
    print(arr)
    print("Sorted array: ", selection_sort(arr))
