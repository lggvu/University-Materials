'''
Implementing a Stack (LIFO) using a sigly linked list
The operations push() and pop() both cost O(1)
'''
from linked_list import *


class Stack:
    def __init__(self):
        self.head = None

    def isempty(self):
        if self.head is None:
            return True
        else:
            return False

    def push(self, data):
        if self.isempty():
            self.head = Node(data)
        else:
            new_node = Node(data)
            new_node.next = self.head
            self.head = new_node

    def pop(self):
        if self.isempty():
            return None
        else:
            e = self.head
            self.head = self.head.next
            e.next = None
            return e.data

    def display(self):
        ele = self.head
        if self.isempty():
            print('Stack underflow')
        else:
            while ele is not None:
                print(str(ele.data) + ' -> ', end=' ')
                ele = ele.next
            return


# Driver code
if __name__ == '__main__':
    s = Stack()
    s.push(1)
    s.push(2)
    s.push(5)
    ls = [i for i in range(30)]
    for i in range(len(ls)):
        s.push(i)
    print(s.display())
    print('Popped: ', s.pop())  # LIFO
    print('Popped: ', s.pop())
    print(s.display())
