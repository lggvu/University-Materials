def merge(L, R, arr):
    i = j = k = 0
    while i < len(L) and j < len(R):
        if L[i] < R[j]:
            arr[k] = L[i]
            i += 1
        else:
            arr[k] = R[j]
            j += 1
        k += 1

    # Checking if any element was left
    while i < len(L):
        arr[k] = L[i]
        i += 1
        k += 1

    while j < len(R):
        arr[k] = R[j]
        j += 1
        k += 1


def merge_sort(arr):
    n = len(arr)

    if n > 1:
        mid = (n+1) // 2
        L = arr[:mid]
        R = arr[mid:]
        merge_sort(L)
        # print(f'Implement merge_sort({L})')
        merge_sort(R)
        # print(f'Implement merge_sort({R})')
        merge(L, R, arr)
        #print(f'merge({L}, {R}, arr)')
    return arr

if __name__ == '__main__':
    arr = [85, 24, 63, 45, 17, 31, 96, 50]
    print('Original array: ', arr)
    print('->', merge_sort(arr))