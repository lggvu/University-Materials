'''
Stack (LIFO) implementation using two queues (FIFO)
The time complexity for pushing is O(n)
The time complexity for popping is O(1)
'''


class Stack():
    def __init__(self):
        self.q1 = []
        self.q2 = []

    def empty(self):
        self.q = q1
        self.q = q2
        if len(self.q) == 0:
            return True
        return False

    def push(self, e):
        if not self.q1:
            self.q1.append(e)
        else:
            for _ in range(len(self.q1)):
                self.q2.append(self.q1.pop())
            self.q1.append(e)
            for _ in range(len(self.q1)):
                self.q1.append(self.q2.pop())

    def pop(self):
        e = self.q1.pop()
        return e

    def display(self):
        ele = self.head
        if self.isempty():
            print('Stack underflow')
        else:
            while ele is not None:
                print(str(ele.data) + ' -> ', end=' ')
                ele = ele.next
            return


# Driver code
if __name__ == '__main__':
    s = Stack()
    s.push(1)
    s.push(2)
    s.push(5)
    ls = [i for i in range(30)]
    for i in range(len(ls)):
        s.push(i)
    print(s.display())
    print('Popped: ', s.pop())  # LIFO
    print('Popped: ', s.pop())
    print(s.display())
