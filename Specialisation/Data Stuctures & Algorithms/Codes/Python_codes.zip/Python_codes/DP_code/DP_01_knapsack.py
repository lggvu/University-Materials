'''
list w: weight of each item 
list v: value of each item 
n: total number of items
W: initial capacity of the knapsack
'''
import numpy as np


def knapsack(W, w, v, n):
	K = np.zeros(shape=((n, W+1)), dtype=int)

	for i in range(n):
		K[i, 0] = 0  # base case
	for j in range(W+1):
		if w[0] <= j:
			K[0, j] = v[0]
		else:
			K[0, j] = 0 
	for i in range(1, n):
		for j in range(W+1):
			if j < w[i]:
				K[i, j] = K[i-1, j]
			else:
				K[i, j] = max(K[i-1, j], K[i-1, j-w[i]]+v[i])
	return K


def find_sol():
	t = knapsack(W, w, v, n)
	i, j = n-1, W 
	cur = t[i, j]
	used = []
	stop = False
	sum_weight = []

	while not stop:
		cur = t[i, j]
		if cur == t[i-1, j]:
			i, j = i-1, j 
		else:
			used.append(i+1)
			sum_weight.append(w[i])
			i, j = i-1, j-w[i]
		if sum(sum_weight) == W:
			stop = True
			
	return used


def print_sol():
	table = knapsack(W, w, v, n)
	print('i/j'.ljust(10), end='| ')
	for i in range(W):
		print(f'{i:3}', end=' | ')
	print(f'{W:3} | ')
	print('-' * (11+6*(W+1)))
	for i in range(len(table)):
		print(f'w[{i+1}] = {w[i]}'.ljust(10), end='| ')
		for j in table[i]:
			print(f'{j:3}', end=' | ')
		print()
	print()
	print('Maximum value in the knapsack:', table[n-1, W])


if __name__ == '__main__':
	print('DYNAMIC PROGRAMMING: 0-1 Knapsack problem')
	print()

	## TYPE YOUR INPUT HERE ================== ##
	w = [10, 20, 30]  # list of weights
	v = [60, 100, 120] # list of value
	W = 50  # initial capacity
	## ======================================= ##
	n = len(w)  # number of items
	## ======================================= ##
	print('Weight list:', w)
	print('Value list:', v)
	print('The number of items:', n)
	print('Initial capacity:', W)
	print('===== RESULT =====')
	print()
	print_sol()
	print('Items in the knapsack:', find_sol())


