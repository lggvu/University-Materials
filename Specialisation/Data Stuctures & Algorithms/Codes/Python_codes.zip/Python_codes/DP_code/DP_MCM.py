'''
int n: the number of matrices + 1
list d: sizes of matrices with (n+1) elements
'''
import numpy as np



def MCM(d, n):
	# add more rows/columns to facilitate the indexing
	M = np.zeros(shape=((n+1, n+1)), dtype=int)
	K = np.zeros(shape=((n+1, n+1)), dtype=int)  # accumulating index of parentheses
	for i in range(n):
		M[i, i] = 0  # base case
	for s in range(2, n):  # go diagonally
		for i in range(1, n-s+1):
			min = 1e5
			j = i + s - 1
			for k in range(i, j):
				temp = M[i, k] + M[k+1, j] + d[i-1]*d[k]*d[j]
				if temp < min:
					min = temp
					K[i, j] = k
			M[i, j] = min
	# refining the final results
	M = np.delete(M, [0, M.shape[0]-1], 0)
	M = np.delete(M, [0, M.shape[1]-1], 1)
	K = np.delete(K, [0, K.shape[0]-1], 0)
	K = np.delete(K, [0, K.shape[1]-1], 1)

	return M, K


def find_sol():
	M, K = MCM(d, n)
	i, j = 0, n-2
	cur = K[i, j]
	index = []
	stop = False  # stop when the size of all problems do not exceed 1

	while not stop:
		cur = K[i, j]
		index.append(cur)
		par = [[i, cur-1], [cur, j]]  # two subproblems
		i = cur
		if par[0][1] - par[0][0] <= 1 and par[1][1] - par[1][0] <= 1:
			stop=True
	
	return index


def print_sol():
	M, K = MCM(d, n)
	table = [[f'{M[i, j]}/{K[i, j]}' for j in range(n-1)] for i in range(n-1)]
	for row in table:
		for ele in row:
			print(ele.rjust(10), end=' ')
		print()
	print('Minimum number of scalar multiplcations needed:', M[0, n-2])




if __name__ == '__main__':
	print('DYNAMIC PROGRAMMING: Matrix Chain Multiplication')
	print()

	## TYPE YOUR INPUT HERE ================== ##
	d = [10, 100, 20, 5, 80]  # list of sizes
	## ======================================= ##
	n = len(d)  # number of matrix + 1
	## ======================================= ##
	print('Sizes list:', d)
	print('The number of matrices:', n-1)
	print('===== RESULT =====')
	print()
	print_sol()
	print('Index of parentheses (index of matrix starts at 1):', find_sol())




