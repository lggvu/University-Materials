import numpy as np


def floyd(L):
	n = len(L)
	D = L
	P = np.zeros(shape=(n, n), dtype=int)  # accumulating the index

	for k in range(n):
		for i in range(n):
			for j in range(n):
				temp = D[i, k] + D[k, j]
				if temp < D[i, j]:
					D[i, j] = temp
					P[i, j] = k+1

	return D, P


def print_sol(L):  # just like the main function, but will not return D and P
	n = len(L)
	D = L
	P = np.zeros(shape=(n, n), dtype=int)  # accumulating the index

	for k in range(n):
		for i in range(n):
			for j in range(n):
				temp = D[i, k] + D[k, j]
				if temp < D[i, j]:
					D[i, j] = temp
					P[i, j] = k+1
		print(f'D{k+1} = {D}')  # I tried using list to store the intermediary results, but did not work???
		print(f'P{k+1} = {P}')
		print()


def find_sol(D, P, i, j):
	# D, P = floyd(L)
	# print(D)
	# print(P)
	path = [i]
	i, j = i-1, j-1
	stop = False
	
	while not stop:
		node = P[i, j]
		if node != 0:
			path.append(node)
		i = node-1

		if node == 0:
			stop = True

	path.append(j+1)
	return path


if __name__ == '__main__':
	print('DYNAMIC PROGRAMMING: Floyd-Warshall Algorithm')
	print()
	INF = 99999

	## TYPE YOUR INPUT HERE ================== ##
	# distance matrix, use numpy
	L = np.array([
		[0, 3, 8, INF, 4],
		[INF, 0, INF, 1, 7],
		[INF, 4, 0, INF, INF],
		[2, INF, 5, 0, INF],
		[INF, INF, INF, 6, 0]
		])  
	## ======================================= ##
	print('===== RESULT =====')
	print()
	print('Process:')
	print_sol(L)

	# NOTE: Uncomment the following codes if you want to find the detailed path
	# D, P = floyd(L)
	# start = 5  # index starts at 1
	# goal = 2
	# print(f'Path from {start} to {goal}: {find_sol(D, P, start, goal)}')


