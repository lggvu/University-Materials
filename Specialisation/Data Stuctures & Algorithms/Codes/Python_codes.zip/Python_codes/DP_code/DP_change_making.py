'''
N: the amount to return
list d: value of each coin 
n: number of denominations
'''
import numpy as np


def making_change(d, n, N):
	t = np.zeros(shape=(n, N+1), dtype=int)
	for i in range(n):
		t[i, 0] = 0  # base case

	for i in range(n):
		for j in range(N+1):
			if i == 0:
				t[i, j] = t[i, j-d[i]] + 1
			elif j < d[i]:
				t[i, j] = t[i-1, j] 
			else:
				t[i, j] = min(t[i-1, j], t[i, j-d[i]] + 1)

	for i in range(n):  # all element - 1 due to the index in Python
		for j in range(N+1):
			t[i][j] -= 1
	return t


def find_sol():
	t = making_change(d, n, N)
	i, j = n-1, N 
	cur = t[n-1, N]
	used = []
	stop = False
	while not stop:
		cur = t[i, j]
		if cur == t[i-1, j]:
			i, j = i-1, j 
		if cur == (t[i, j-d[i]] + 1):
			used.append(d[i])
			i, j = i, j-d[i]
		if sum(used) == N:
			stop=True

	return used



def print_sol():
	table = making_change(d, n, N)
	print('Coins/Amounts'.ljust(15), end='| ')
	for i in range(N):
		print(f'{i:3}', end=' | ')
	print(f'{N:3} | ')
	print('-' * (16+6*(N+1)))
	for i in range(len(table)):
		print(f'd[{i+1}] = {d[i]}'.ljust(15), end='| ')
		for j in table[i]:
			print(f'{j:3}', end=' | ')
		print()
	print()
	print('Minimum number of coins needed:', table[n-1, N])


if __name__ == '__main__':
	print('DYNAMIC PROGRAMMING: Change-making problem')
	print()

	## TYPE YOUR INPUT HERE ================== ##
	d = [1, 2, 3]  # list of value of each denomination
	N = 7  # the money we need to return
	## ======================================= ##
	n = len(d)
	## ======================================= ##
	print('The number of denominations:', n)
	print('Value of each denomination:', d)
	print('The amount of money we need to return:', N)
	print('===== RESULT =====')
	print()
	print_sol()
	print('Coins used:', find_sol())




