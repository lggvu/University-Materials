def heapify(arr, n, i):
    l = 2*i +1 # root is at index 1
    r = 2*i + 2

    if l < n and arr[l] > arr[i]:
        largest = l
    else:
        largest = i

    if r < n and arr[r] > arr[largest]:
        largest = r

    if largest != i:
        print(f'Execute heapify(arr, {i+1}), swap(A, {i+1}, {largest+1})')
        arr[i], arr[largest] = arr[largest], arr[i]
        print_heap(arr)
        heapify(arr, n, largest)


def buildheap(arr):
    n = len(arr)
    start = n // 2 - 1
    print("Start:", start+1)
    for i in range(start, -1, -1):
        heapify(arr, n, i)

    return arr

def print_heap(arr):
    n = len(arr)
    for i in range(n):
        print(arr[i], end=' ')
    print()

def heap_sort(arr):
    print("---Start buildheap---")
    buildheap(arr)
    print("-> MaxHeap array:", arr)

    print("---Start HeapSort---")
    n = len(arr)
    for i in range(n-1, 0, -1):
        print("Iteration: i =", i+1)
        print(f'swap({arr[i]}, {arr[0]})')
        arr[i], arr[0] = arr[0], arr[i]
        heapify(arr, i, 0)

    return arr

if __name__ == '__main__':
    # arr = [3, 15, 2, 29, 6, 14, 25, 7, 5]
    # n = len(arr)
    # print('Original heap: ', arr)
    # print("The sorted array is: ", heap_sort(arr))

    arr = [25, 67, 56, 32, 12, 96, 82, 44]
    n = len(arr)
    print(heap_sort(arr))


