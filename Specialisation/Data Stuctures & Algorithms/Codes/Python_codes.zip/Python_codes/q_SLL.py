'''
Implement Queue (FIFO) using a singly linked list
The operations enqueue() and dequeue() both cost O(1)
'''


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class Queue:
    def __init__(self):
        self.front = None
        self.rear = None

    def isempty(self):
        if self.front is None and self.rear is None:
            return True
        else:
            return False

    def enQueue(self, data):
        new_node = Node(data)
        if self.rear is None:
            self.front = self.rear = new_node
            return

        self.rear.next = new_node
        self.rear = new_node

    def deQueue(self):
        if self.isempty():
            return
        e = self.front
        self.front = e.next
        if (self.front is None):
            self.rear = None


# Driver Code
if __name__ == '__main__':
    q = Queue()
    q.enQueue(10)
    q.enQueue(20)
    q.deQueue()
    q.deQueue()
    q.enQueue(30)
    q.enQueue(40)
    q.enQueue(50)
    q.deQueue()
    print("Queue Front " + str(q.front.data))
    print("Queue Rear " + str(q.rear.data))
