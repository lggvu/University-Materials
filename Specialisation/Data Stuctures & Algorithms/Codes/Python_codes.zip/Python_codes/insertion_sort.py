import random
import time

def insertion_sort(arr):
    n = len(arr)
    for i in range(1, n):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j+1] = arr[j]
            j -= 1
        arr[j+1] = key

    return arr


if __name__ == '__main__':
    # n = int(input('Length of the array: '))
    # # arr = [random.randint(1, n) for _ in range(n)]
    # print(arr)
    # print(insertion_sort(arr))
    # start = time.time()
    # insertion_sort(arr)
    # end = time.time()
    # print(f'Excecution time: {end-start}s')

    arr = [1, 9, 4, 5, 0, 8, 6, 13, 21, 15, 7]
    print(arr)
    print("Sorted array: ", insertion_sort(arr))



'''
Insertion sort seems to take a little bit longer 
'''