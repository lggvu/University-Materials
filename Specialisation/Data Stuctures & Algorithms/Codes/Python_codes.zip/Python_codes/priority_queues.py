def insert(A, key):
    heap_size = len(A)
    heap_size += 1
    A.append(key)
    i = heap_size
    while i > 1 and A[(i//2)-1] < A[i-1]:
        A[i-1], A[(i//2)-1] = A[(i//2)-1], A[i-1]
        i = i//2
    return A


if __name__ == '__main__':
    A = [15, 13, 9, 5, 12, 8, 7, 4, 0, 6, 2, 1]
    print(insert(A, 3))