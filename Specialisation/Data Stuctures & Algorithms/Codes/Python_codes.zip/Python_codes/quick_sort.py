from time import time

def partition(arr, p, r):
    pivot = arr[r]  # pivot is the last element
    i = p - 1
    for j in range(p, r):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i+1], arr[r] = arr[r], arr[i+1]

    return (i + 1)


def quicksort(arr, p, r):
    if p < r:  # the array has at least 2 elements
        q = partition(arr, p ,r)  # pivot
        print("Pivot q = ", q)
        quicksort(arr, p, q-1)
        print(f"Implement quicksort(arr, {p}, {q-1})")
        quicksort(arr, q+1, r)
        print(f"Implement quicksort(arr, {q+1}, {r})")


if __name__ == '__main__':
    arr = [7, 11, 14, 6, 9, 4, 3, 12]
    n = len(arr)
    start = time()
    quicksort(arr, 0, n - 1)
    print("Sorted array is:")
    end = time()
    for i in range(n):
        print(arr[i], end=' ')
    print()
    print(f"Total execution time: {end-start}s")