def last():
	for i in range(1, m+1):
		if arr[i] != n-m+i:
			return False
	return True


def Successive_Generation():
	i = m
	while (arr[i] == n-m+i):
		i -= 1
	arr[i] = arr[i] + 1
	for j in range(i+1, m+1):
		arr[j] = arr[i] + j - i


def Generate():
	stop = False
	while not stop:
		for i in range(1, m+1):
			print(arr[i], end=' ')
		print()
		if not last():
			Successive_Generation()
		else:
			stop = True



n = int(input('Value of n: '))
m = int(input('Value of m: '))

arr=[1, 2, 3, 4, 5, 6, 7]
for i in range(1, m+1):
	arr[i] = i

Generate()
