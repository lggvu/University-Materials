def Try(k):
	# S_k = (0, 1)
	for y in range(0, 2):
		a[k] = y 
		if k == n-1:
			print_sol()
		else:
			Try(k+1)


def print_sol():
	for i in range(n):
		print(a[i], end=' ')
	print()


n = int(input('Length of the binary string: n = '))
a = [0 for _ in range(n)]

Try(0)

