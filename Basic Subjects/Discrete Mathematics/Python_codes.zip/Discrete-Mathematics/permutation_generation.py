def last():
	for i in range(1, n+1):
		if arr[i] != n-i+1:
			return False
	return True 


def Successive_Generation():
	# find j as the max index s.t a_j < a_(j+1)
	j = n - 1
	while arr[j] > arr[j+1]:
		j = j - 1
	# find a_k as the smallest number on the right of a_j, and > a_j
	k = n 
	while arr[j] > arr[k]:
		k = k - 1
	arr[j], arr[k] = arr[k], arr[j]
	# inverting the sequence a_j+1 to a_n
	right = n
	left = j + 1
	while right >= left:
		arr[right], arr[left] = arr[left], arr[right]
		right -= 1
		left += 1


def Generate():
	stop = False
	for i in range(1, n+1):
		arr[i] = i 
	while not stop:
		for i in range(1, n+1):
			print(arr[i],  end=' ')
		print()
		if not last():
			Successive_Generation()
		else:
			stop = True


n = int(input('Enter value of n: '))
arr = [0] * (n+1)8
Generate()