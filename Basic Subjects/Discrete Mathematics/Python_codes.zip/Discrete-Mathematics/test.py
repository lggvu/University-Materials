def inp(filename):
    with open(filename) as f:
        [n] = [int(x) for x in f.readline().split()]
        graph = []
        for _ in range(n):
            r = [int(x) for x in f.readline().split()]
            graph.append(r)
    return n, graph


def branch(k):
    for v in range(1, n+1):
        if visited[v] == False:
            x[k= v
            visited[v] = True
            f  = f + c(x[k-1], x[k])
            if k == (n-1):
                if f + c(x[n-1], x[0]) < f_opt:  # update record
                    f_opt = f + c(x[n-1], x[0])
            else:
                g = f + (n-k) * c_min  # lower bound
                if g < f_opt:
                    branch(k+1)
        # return to the old states
        f = f - c(x[k-1], x[k])
        visited[k] = False

if __name__ == '__main__':
    filename = 'tsp-01'
    n, graph = inp(filename)
    for i in range(graph):
        small.append(min(i))
    c_min = min(small)
