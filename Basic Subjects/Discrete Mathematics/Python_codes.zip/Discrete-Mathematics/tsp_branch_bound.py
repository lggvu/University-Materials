def inp(filename):
    with open(filename) as f:
        [n] = [int(x) for x in f.readline().split()]
        c = []
        for _ in range(n):
            r = [int(x) for x in f.readline().split()]
            c.append(r)
    return n, c


def branch(k):
    global f, f_opt, x, c_min, visited, path
    for v in range(1, n):
        if visited[v] is False:
            x[k] = v
            visited[v] = True
            f = f + c[x[k-1]][x[k]]
            if k == (n-1):
                if (f + c[x[n-1]][x[0]]) < f_opt:
                    f_opt = f + c[x[n-1]][x[0]]  # update record
                    path = x[:]
            else:
                g = f + (n-k) * c_min  # lower bound
                if g <= f_opt:
                    branch(k+1)
        # return to the old states
            f = f - c[x[k-1]][x[k]]
            visited[v] = False


if __name__ == '__main__':
        filename = 'tsp-01'
        n, c = inp(filename)
        x = [0 for _ in range(n+1)]
        f_opt = float('INF')
        f = 0
        x[0] = 0  # root node
        visited = [False for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if i == j:
                    c[i][j] = 1e5
        c_min = int(min(min([i for i in c])))
        visited[x[0]] = True  # root node
        path = []
        branch(1)
        print('The optimal cost is:', f_opt)
        print('The optimal path is:', end= ' ')
        for i in path:
            print(i+1, end=' ')
