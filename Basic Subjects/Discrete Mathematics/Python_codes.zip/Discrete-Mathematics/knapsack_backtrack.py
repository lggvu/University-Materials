def backtrack(k):
    global c, ck, fk, f_opt, x, x_opt
    if ck >= w[k]:
        t = 1
    else:
        t = 0
    for j in range(0, t+1):
        x[k] = j
        ck = ck - w[k]*x[k]
        fk = fk + p[k]*x[k]
        if k == n-1:
            if fk > f_opt:
                x_opt = x
                f_opt = fk
        else:
            backtrack(k+1)
        ck = ck + w[k]*x[k]
        fk = fk - p[k]*x[k]
    return f_opt, x_opt


def print_sol():
    f_opt, x_opt = backtrack(0)
    print('The optimal weight is: ', f_opt)
    print('The items included are: ', end='')
    for i in range(len(x_opt)):
        if x_opt[i] == 1:
            print(w[i], end=' ')


if __name__ == '__main__':
    w = [10, 7, 4, 2]
    p = [60, 28, 20, 24]
    n = len(w)
    x = [0 for _ in range(n)]
    x_opt = [0 for _ in range(n)]
    c = 11  # capacity
    ck = c
    fk = 0
    f_opt = 0

    print_sol()
