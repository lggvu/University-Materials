'''
def candidate(j, k):
	# j is a candidate if j is in S_k = N\{a1, a2,..., a_(k-1)}
	for i in range(1, k):
		if j == a[i]:
			return 0
	else:
		return 1


def Try(k):
	for j in range(1, n+1):
		if candidate(j, k):
			a[k] = j
			if k == n:
				print_sol()
			else:
				Try(k+1)


def print_sol():
	for i in range(1, n+1):
		print(a[i], end=' ')
	print()
'''


def permutation(k=0, S=[]):
	global visited
	if k == n:
		print(S)
		return
	for i in range(1, n + 1):
		if visited[i - 1] == False:
			visited[i - 1] = True
			permutation(k + 1, S + [i])
			visited[i - 1] = False  # return the variables to the old state


if __name__ == '__main__':
	n = int(input())
	visited = [False for _ in range(n)]
	print(permutation())
