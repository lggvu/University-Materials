 def Try(k):
	# S_k = (0, 1)
	for y in range(a[k-1]+1, n-m+k+1):
		a[k] = y 
		if k==m:
			print_sol()
		else:
			Try(k+1)


def print_sol():
	for i in range(1, m+1):
		print(a[i], end=' ')
	print()


n = int(input('Value of n = '))
m = int(input('Value of m = '))

a = [0] * (m+1)

Try(1)
