def inp(filename):
    with open(filename) as f:
        [n] = [int(x) for x in f.readline().split()]
        graph = []
        for _ in range(n):
            r = [int(x) for x in f.readline().split()]
            graph.append(r)
    return n, graph


def tsp(graph, visited, current, n, count, cost):
    global path
    if count == n and graph[current][0]:  # original position
        ans.append(cost + graph[current][0])
        return

    for i in range(n):
        if visited[i] is False and graph[current][i]:
            visited[i] = True
            tsp(graph, visited, i, n, count+1, cost + graph[current][i])
            visited[i] = False




if __name__ == '__main__':
    filename = 'tsp-02'
    n, graph = inp(filename)
    visited = [False for _ in range(n)]
    visited[0] = True  # root node
    ans = []

    tsp(graph, visited, 0, n, 1, 0)

    print('The optimal cost is:', min(ans))

