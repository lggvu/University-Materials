import numpy as np

def binary_search(low, high, A, key):
    if (low <= high):
        mid = (low + high) // 2
        if (A[mid] == key):
            return mid
        elif (key < A[mid]):
            return binary_search(low, mid-1, A, key)
        else:
            return binary_search(mid+1, high, A, key)
    else:
        return -1


if __name__ == '__main__':
    # A = np.random.randint(0, high=9, size=10)
    A = [1, 3, 7, 9, 5, 2, 8, 9]
    print(A)
    print('The index of the key is: ',binary_search(0, len(A), A, 5))