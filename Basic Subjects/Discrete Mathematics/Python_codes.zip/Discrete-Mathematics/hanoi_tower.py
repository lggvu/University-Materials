count = 0
def hanoi_tower(n, a, c, b):  # (number of disks, start, end, spare)
    global count
    if (n==1):
        print(f'Move from {a} to {c}')
        count += 1
    else:
        hanoi_tower(n-1, a, b, c)
        hanoi_tower(1, a, c, b)
        hanoi_tower(n-1, b, c, a)
    return count

print(hanoi_tower(int(input()), 'A', 'C', 'B'))