def last():
	# return true if b1..bn si already the final
	for i in range(1, n+1):
		if b[i] == 0:
			return False 
	return True 

def Successive_Generation():
	i = n 
	while b[i] == 1:
		b[i] = 0
		i = i - 1
	b[i] = 1


def Generate():
	global b
	b = [0] * (n+1)
	stop = False
	while not stop:
		for i in range(1. n+1):
			print(b[i], end=' ')
		print()
		if not (last()):
			Successive_Generation()
		else:
			stop = True


n = int(input('Enter value of n: '))
Generate(n)

